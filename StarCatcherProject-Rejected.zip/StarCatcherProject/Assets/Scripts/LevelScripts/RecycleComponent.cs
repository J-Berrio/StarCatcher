﻿using UnityEngine;
using System.Collections;

public class RecycleComponent : MonoBehaviour 
{
	private Vector3 newLocation;

	void Start()
	{
		StaticVars.nextSectionPos = 273.5f;
	}

	void OnTriggerEnter ()
	{
		newLocation.x = StaticVars.nextSectionPos;
		transform.localPosition = newLocation;
		StaticVars.nextSectionPos += StaticVars.distance;
	}
}
