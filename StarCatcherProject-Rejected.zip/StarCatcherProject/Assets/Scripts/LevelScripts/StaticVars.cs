﻿public class StaticVars

{
	public static float distance = 54.7f;
	public static float nextSectionPos = 273.5f;
}
