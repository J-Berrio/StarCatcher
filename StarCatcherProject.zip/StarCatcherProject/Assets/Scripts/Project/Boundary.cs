﻿using UnityEngine;
using System.Collections;

public class Boundary : MonoBehaviour
{
	//for first collider put destroy object and respawn at beginning. 
	void Start () 
	{
	
	}
	
	void Update () 
	{
	
	}

	void OnTriggerEnter ()
	{
		
	}
}
