﻿public class StaticVars

{
	public static float distance = 54.811f;
	public static float nextSectionPos = 274.055f;
	 
	// distance = 54.811, nextSectionPos = 274.055
	// distance = 54.7f, nextSectionPos = 273.5f
}
